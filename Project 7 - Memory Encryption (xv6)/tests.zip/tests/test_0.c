#include "param.h"
#include "types.h"
#include "stat.h"
#include "user.h"

#define PGSIZE 4096


int main(void) {

    printf(1, "XV6_TEST_OUTPUT PASS!\n");
    exit();
}
